!#/bin/bash

sudo service nginx reload

sudo touch Venkata